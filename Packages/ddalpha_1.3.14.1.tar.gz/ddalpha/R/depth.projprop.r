################################################################################
# File:             depth.projprop.r
# Created by:       Anna Malinovskaya
# Last changes:     19.05.2023
#
# 
# Computation of the approximate projection data depth and exact data depths.
################################################################################

depth.projprop <- function(x, data, depth = "projection", num.directions = 1000, solver = "RefinedGrid",
                           solverParams = list(nref = 10, alpha = 0.5),  seed = 0){
  
  # Set Seed
  if (seed!=0) set.seed(seed)
  
  # Data Check and Preparation
  if (!(is.matrix(data) && is.numeric(data)
        || is.data.frame(data) && prod(sapply(data, is.numeric))) 
      || ncol(data) < 2){
    stop("Argument \"data\" should be a numeric matrix of at least 2-dimensional data")
  }
  if (!is.matrix(x) 
      && is.vector(x)){
    x <- matrix(x, nrow=1)
  }
  
  # Preparation Arguments for C++ function
 
    dt <- as.vector(t(data))
    z <- as.vector(t(x))
    m <- nrow(x)
    d <- ncol(data)
    if (ncol(x) != ncol(data)){
      stop("Argument \"x\" and argument \"data\" should have the same dimension")
    }
    n <- nrow(data)
    k <-  num.directions
    
    
    
  # Set Depth, Approximation Method and Parameters
    
    # The same order as in C++ enum class eDepth { MD, HD, ZD, PD, APD }, eProjMeth;
    eDepth = c("mahalanobis", "halfspace", "zonoid", "projection", "asymmprojection")
    eProjMeth = c("SimpleGrid", "RefinedGrid", "SimpleRandom", "RefinedRandom",
                   "CoordDesc", "RandSimp", "NelderMead", "SimAnn", "CoordDescGC", "NelderMeadGC")
     
    
    
    #if (depth == "projection" || depth == "asymmprojection"){
      depthnotion = which(eDepth == depth) - 1
      
      if (solver == "SimpleGrid" || solver == "SimpleRandom"){
          solverchoice = which(eProjMeth == solver) - 1
          par1 = -1
          par2 = -1
          par3 = -1
      } else if (solver == "RefinedGrid" || solver == "RefinedRandom"){
          solverchoice = which(eProjMeth == solver) - 1
          par1 = solverParams$nref
          par2 = solverParams$alpha
          par3 = -1
      } else if (solver == "RandSimp") {
          solverchoice = which(eProjMeth == solver) - 1
          par1 = solverParams$alpha
          par2 = -1
          par3 = -1
      } else if (solver == "SimAnn") {
          solverchoice = which(eProjMeth == solver) - 1
          par1 = solverParams$alpha
          par2 = solverParams$beta
          par3 = ifelse(solverParams$start == "Mn", 0, 1) #Starting value (0 = mean, 1 = random)
      } else if (solver == "CoordDesc") {
          solverchoice = ifelse(solverParams$space == "Ec", which(eProjMeth == "CoordDesc") - 1, which(eProjMeth == "CoordDescGC") - 1)
          par1 = ifelse(solverParams$LS == "Eq", 0, 1)
          par2 = -1
          par3 = -1
      } else if (solver == "NelderMead") {
          solverchoice =  ifelse(solverParams$space == "Ec", which(eProjMeth == "NelderMead") - 1, which(eProjMeth == "NelderMeadGC") - 1)
          par1 = solverParams$beta
          par2 = ifelse(solverParams$bound == "y", 1, 0) #Bound movement on great circles (0 = no, 1 = yes)
          par3 = ifelse(solverParams$start == "Mn", 0, 1) #Starting value (0 = mean, 1 = random)
      }
      
    
    
    q <- 1
    
    rez <- .C("ProjPropDepth", 
              as.double(z), 
              as.double(dt), 
              as.integer(m), 
              as.integer(n), 
              as.integer(d), 
              as.integer(k),
              as.integer(seed),
              as.integer(depthnotion),
              as.integer(solverchoice),
              as.double(par1),
              as.double(par2),
              as.double(par3),
              dps=double(m*q))
    return (rez$dps)
  }
  


