void LensDepth(TDMatrix X, TDMatrix x, int d, int n, int nx, double beta,
               int distType, double p, TDMatrix sigma, double* depths);
