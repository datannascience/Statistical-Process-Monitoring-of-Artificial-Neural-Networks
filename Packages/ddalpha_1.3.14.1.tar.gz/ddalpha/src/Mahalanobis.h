
void MahalanobisDepth(TDMatrix X, TDMatrix x, int d, int n, int nx, double MCD, double *depths);
