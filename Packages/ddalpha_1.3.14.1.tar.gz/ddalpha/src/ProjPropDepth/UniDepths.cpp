
/******************************************************************************/
/* File:             UniDepths.cpp                                           */
/* Created by:       Anna                                                     */
/* Try 1:            07.02.2022                                               */
/*                                                                            */
/* Contains functions that compute the univariate depths of a point w.r.t. a  */
/* data cloud.                                                                */
/*                                                                            */
/******************************************************************************/

#define _USE_MATH_DEFINES
#include <algorithm>
#include <cstring>
#include <float.h>
#include <iostream>
#include <math.h>
#include <stdexcept>
#include <stdlib.h>
#include "auxLinAlg.h"
#include "Matrix.h"
#include "UniDepths.h"

using namespace std;
using namespace dyMatrixClass;


namespace DataDepth {
	/****************************************************************************/
	/* ZD1 computes the zonoid depth for univariate data.                       */
	/*                                                                          */
	/* The algorithm used here is capable of computing the zonoid depth with a  */
	/* complexity of O(n). The algorithm will be published in a forthcoming     */
	/* paper. Do not use this algorithm without permission of the author.       */
	/*                                                                          */
	/* Args:                                                                    */
	/*   z - the point for which to calculate the depth,                        */
	/*   x - the data w.r.t. which the depth has to be computed, (vector of     */
	/*       dimension n),                                                      */
	/*   n - number of the data points.                                         */
	/*   sorted - optional parameter that indicates that the array x is sorted  */
	/*            in ascending order when 'sorted' is true. Otherwise, the      */
	/*            array x is not sorted                                         */
	/* Returns:                                                                 */
	/*   zonoid depth of z w.r.t. x.                                            */
	/****************************************************************************/

	double ZD1(double z, const double* xx, int n, bool sorted) {
		double Sum = 0, SumNeu, mark, delta, temp, min = DBL_MAX, max = -DBL_MAX;
		double* x;
		int l, r, i, j;

		x = new double[n];
		for (int i = 0; i < n; i++) {
			x[i] = xx[i];
			Sum += x[i];
		};
		if (z * n == Sum) return 1.0;

		if (z * n > Sum) {
			for (int i = 0; i < n; i++) x[i] = -x[i];
			z = -z;
		}
		l = 0;
		r = n - 1;
		Sum = 0;
		while (l < r) {
			i = l;
			j = r;
			mark = x[(l + r) / 2];
			/* A problem could occur, if mark = x[r] and all other elements are less than a[r].
			  In that case i == r+1 after the do-while-loop and we run into an infinite loop.
			  */
			do {
				while (x[i] < mark) i++;
				while (x[j] > mark) j--;
				if (i <= j) {
					temp = x[i];
					x[i] = x[j];
					x[j] = temp;
					i++;
					j--;
				}
			} while (i <= j);
			SumNeu = Sum;
			for (int k = l; k < i; k++) SumNeu += x[k];
			if (SumNeu <= z * i) {
				l = i;
				Sum = SumNeu;
			}
			else {
				r = i - 1;
			}
		}
		delta = (l * z - Sum) / (x[l] - z);

		delete[] x;
		return (l + delta) / n;
	}


	/****************************************************************************/
	/*                                                                          */
	/* 'med' computes the median of an array x of length n.                     */
	/*                                                                          */
	/****************************************************************************/

	double med(double* x, int n) {
		int m;
		if (n & 1) { // n odd
			m = (n - 1) / 2;
			nth_element(x, x + m, x + n);
			return x[m];
		}
		else {  // n even
			m = n / 2 - 1;
			nth_element(x, x + m, x + n);
			return(x[m] + *min_element(x + m + 1, x + n)) / 2;
		}
	}

	/****************************************************************************/
	/*                                                                          */
	/* 'mad' computes the median of absolute deviations from the median.        */
	/* The median of the data in x is passed as a parameter 'med'               */
	/*                                                                          */
	/****************************************************************************/

	double mad(double* x, int n, double med) {
		for (int i = 0; i < n; i++) {
			x[i] = abs(x[i] - med);
		}
		int m = (n & 1) ? (n - 1) / 2 : n / 2;
		nth_element(x, x + m, x + n);
		return x[m];
	}


	/****************************************************************************/
	/* PD1 computes the projection depth for univariate data.                   */
	/*                                                                          */
	/* Args:                                                                    */
	/*   z - the point for which to calculate the depth,                        */
	/*   x - the data w.r.t. which the depth has to be computed, (vector of     */
	/*       dimension n)                                                       */
	/*   n - number of the data points.                                         */
	/* Returns:                                                                 */
	/*   projection depth of z w.r.t. x.                                        */
	/****************************************************************************/

	double PD1(double z, const double* x, int n) {
		double* xCopy = new double[n]; // Copy of "x" as "median(...)" spoils it
		memcpy(xCopy, x, n * sizeof(double));
		double xmed = med(xCopy, n);
		double xmad = mad(xCopy, n, xmed);
		delete[] xCopy;
		return xmad / (xmad + abs(z - xmed));
	}

	/****************************************************************************/
	/* MD1 computes the Mahalanobis depth for univariate data.                  */
	/*                                                                          */
	/* Args:                                                                    */
	/*   z - the point for which to calculate the depth,                        */
	/*   x - the data w.r.t. which the depth has to be computed, (vector of     */
	/*       dimension n),                                                      */
	/*   n - number of the data points.                                         */
	/* Returns:                                                                 */
	/*   Mahalanobis depth of z w.r.t. x.                                        */
	/****************************************************************************/

	double MD1(double z, const double* x, int n) {
		double xquer, var, sum = 0;
		for (int i = 0; i < n; i++) sum += x[i];
		xquer = sum / n;
		sum = 0;
		for (int i = 0; i < n; i++) sum += (x[i] - xquer) * (x[i] - xquer);
		var = sum / n;
		return 1.0 / (1 + (z - xquer) * (z - xquer) / var);
	}

	/* Definition of constants */
	const double eps_HD1 = 1e-8;


	/****************************************************************************/
	/*                                                                          */
	/* 'HD1' computes the hafspace depth of z w.r.t n data points in x.         */
	/*                                                                          */
	/****************************************************************************/

	double HD1(double z, const double* x, int n) {
		int cnt1 = 0, cnt2 = 0;
		for (int i = 0; i < n; i++, x++) {
			double d = *x - z;
			if (d < eps_HD1) cnt1++;
			if (d > -eps_HD1) cnt2++;
		}
		return (double)min(cnt1, cnt2) / (double)n;
	}



	/****************************************************************************/
		/* APD1 computes the asymmetric projection depth for univariate data.       */
		/*                                                                          */
		/* Args:                                                                    */
		/*   z - the point for which to calculate the depth,                        */
		/*   x - the data w.r.t. which the depth has to be computed, (vector of     */
		/*       dimension n)                                                       */
		/*   n - number of the data points.                                         */
		/* Returns:                                                                 */
		/*   asymmetric projection depth of z w.r.t. x.                             */
		/****************************************************************************/

	double APD1(double z, const double* x, int n) {
		double* xCopy = new double[n]; // Copy of "x" as "median(...)" spoils it
		memcpy(xCopy, x, n * sizeof(double));
		// The median is computed as the ceil(n * 0.5)-th smallest element in the
		// array x
		int n2 = ceil(n * 0.5);
		nth_element(xCopy, xCopy + n2, xCopy + n);
		double med{ xCopy[n2] };
		double dev;
		if (z >= med) {
			// The median of positive deviations from the median is computed as
			// the difference between the third quartile and the median
			int n3 = ceil(n * 0.75);
			nth_element(xCopy + n2 + 1, xCopy + n3, xCopy + n);
			dev = xCopy[n3] - med;
		}
		else {
			// The median of negative deviations from the median is computed as
			// the difference between the median and the first quartile.
			int n1 = ceil(n * 0.25);
			nth_element(xCopy, xCopy + n1, xCopy + n2);
			dev = med - xCopy[n1];
		}
		delete[] xCopy;
		return 1.0 / (1.0 + abs(z - med) / dev);
	}
}
