
/******************************************************************************/
/* File:             UniDepths.h                                             */
/* Created by:       Anna                                                     */
/* Try 1:            07.02.2022                                               */
/*                                                                            */
/* Contains functions that compute the univariate depths of a point w.r.t. a  */
/* data cloud.                                                                */
/*                                                                            */
/******************************************************************************/



#pragma once
#include <vector>
#include "Matrix.h"
namespace DataDepth {

	/****************************************************************************/
	/* ZD1 computes the zonoid depth for univariate data.                       */
	/*                                                                          */
	/* The algorithm used here is capable of computing the zonoid depth with a  */
	/* complexity of O(n). The algorithm will be published in a forthcoming     */
	/* paper. Do not use this algorithm without permission of the author.       */
	/*                                                                          */
	/* Args:                                                                    */
	/*   z - the point for which to calculate the depth,                        */
	/*   x - the data w.r.t. which the depth has to be computed, (vector of     */
	/*       dimension n),                                                      */
	/*   n - number of the data points.                                         */
	/*   sorted - optional parameter that indicates that the array x is sorted  */
	/*            in ascending order when 'sorted' is true. Otherwise, the      */
	/*            array x is not sorted                                         */
	/* Returns:                                                                 */
	/*   zonoid depth of z w.r.t. x.                                            */
	/****************************************************************************/
	double ZD1(double z, const double* x, int n, bool sorted = false);

	/****************************************************************************/
	/* PD1 computes the projection depth for univariate data.                   */
	/*                                                                          */
	/* Args:                                                                    */
	/*   z - the point for which to calculate the depth,                        */
	/*   x - the data w.r.t. which the depth has to be computed, (vector of     */
	/*       dimension n)                                                       */
	/*   n - number of the data points.                                         */
	/* Returns:                                                                 */
	/*   projection depth of z w.r.t. x.                                        */
	/****************************************************************************/
	double PD1(double z, const double* x, int n);

	/****************************************************************************/
	/* MD1 computes the Mahalanobis depth for univariate data.                  */
	/*                                                                          */
	/* Args:                                                                    */
	/*   z - the point for which to calculate the depth,                        */
	/*   x - the data w.r.t. which the depth has to be computed, (vector of     */
	/*       dimension n),                                                      */
	/*   n - number of the data points.                                         */
	/* Returns:                                                                 */
	/*   Mahalanobis depth of z w.r.t. x.                                        */
	/****************************************************************************/
	double MD1(double z, const double* x, int n);
	/****************************************************************************/
	 /* HD1 computes the halfspace depth for univariate data.                    */
	 /*                                                                          */
	 /* Args:                                                                    */
	 /*   z  - the point for which to calculate the depth,                       */
	 /*   xx - the data w.r.t. which the depth has to be computed, (vector of    */
	 /*        dimension n)                                                      */
	 /*   n - number of the data points.                                         */
	 /* Returns:                                                                 */
	 /*   halfspace depth of z w.r.t. x.                                         */
	 /****************************************************************************/
	double HD1(double z, const double* xx, int n);

	/****************************************************************************/
	/* APD1 computes the asymmetric projection depth for univariate data.       */
	/*                                                                          */
	/* Args:                                                                    */
	/*   z - the point for which to calculate the depth,                        */
	/*   x - the data w.r.t. which the depth has to be computed, (vector of     */
	/*       dimension n)                                                       */
	/*   n - number of the data points.                                         */
	/* Returns:                                                                 */
	/*   asymmetric projection depth of z w.r.t. x.                             */
	/****************************************************************************/
	double APD1(double z, const double* x, int n);

}
