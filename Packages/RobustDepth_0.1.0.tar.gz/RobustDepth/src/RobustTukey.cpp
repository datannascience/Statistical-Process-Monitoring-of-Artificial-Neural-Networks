#include "incRobustDepth.h"

double RobustTukeyOneApx(double* point, TDMatrix objects, int m, int d,
                         double delta, bool posExt, int nDir, int genDirs,
                         TDMatrix sqrtCov){
  // Allocate temporary structures
  double depth = 1;
  double* prjs = new double[m]; // projection of all the data
  double* curDir = new double[d]; // the current random direction
  double* tmpCurDir = new double[d]; // temporary structure for random dir
  // The main loop through directions
  for (int i = 0; i < nDir; i++){
    // Create one direction dependent on the type of generation
    switch (genDirs){
    case 1: { // Draw random direction uniformly on the unit sphere
      double dirLength = 0;
      for (int j = 0; j < d; j++){
        curDir[j] = R::rnorm(0, 1);
        dirLength += pow(curDir[j], 2);
      }
      dirLength = sqrt(dirLength); // length of the random vector
      for (int j = 0; j < d; j++){
        curDir[j] /= dirLength;
      }
      break;}
    case 2: {
      if (d > 2){
        stop("Angles not implemented for d > 2.");
      }
      double angle = (double) i / nDir * M_PI * 2;
      curDir[0] = cos(angle);
      curDir[1] = sin(angle);
      break;}
    default:
      stop("Unknown way to generate directions.");
    }
    // Apply the affine-invariance transform
    for (int j = 0; j < d; j++){
      tmpCurDir[j] = 0;
      for (int k = 0; k < d; k++){
        tmpCurDir[j] += sqrtCov[j][k] * curDir[k];
      }
    }
    // double curDirNorm = 0;
    // for (int j = 0; j < d; j++){
    //   curDirNorm += pow(tmpCurDir[j], 2);
    // }
    // curDirNorm = sqrt(curDirNorm);
    // Project all data on the random direction
    for (int j = 0; j < m; j++){
      prjs[j] = 0;
      for (int k = 0; k < d; k++){
        // prjs[j] += ((point[k] - objects[j][k]) * curDir[k]) / curDirNorm;
        prjs[j] += (point[k] - objects[j][k]) * tmpCurDir[k];
      }
    }
    // Sort projections
    quickSort(prjs, 0, m - 1);
    // Find projections smaller and larger than zero
    int iZero = 0; // number of observations smaller or equal than zero
    while (prjs[iZero] <= 0 && iZero < m){
      iZero++;
    }
    // Temporary (partial) depth value
    double partDepth = (double)iZero / m;
    // Find the subsum-index
    double subSum1 = 0; // subsum before
    double subSum2 = 0; // subsum after
    int iSubSum = 0; // subsum-index
    // If to take into account points on the other side of the hyperplane
    if (delta > 0){
      double mDelta = m * delta;
      // Selector of direction of adding/subtracting additional observations
      if (posExt){ // if add points on positive side
        for (int j = iZero; j < m; j++){
          if (subSum1 + prjs[j] >= mDelta){
            subSum2 = subSum1 + prjs[j];
            iSubSum = j - iZero + 1;
            break;
          }else{
            subSum1 += prjs[j];
            subSum2 = subSum1;
          }
        }
        // If 'mDelta' larger than largest subsum
        if (subSum2 < mDelta){
          partDepth = 1;
        }else{
          partDepth += (double)(iSubSum - 1) / m +
            (double)(mDelta - subSum1) / (m * prjs[iSubSum - 1 + iZero]);
        }
      }else{ // subtract points on negative side
        for (int j = iZero - 1; j >= 0; j--){
          if (subSum1 - prjs[j] >= mDelta){
            subSum2 = subSum1 - prjs[j];
            iSubSum = iZero - j;
            break;
          }else{
            subSum1 -= prjs[j];
            subSum2 = subSum1;
          }
        }
        // If 'mDelta' larger than largest subsum
        if (subSum2 < mDelta){
          partDepth = 0;
        }else{
          partDepth -= (double)(iSubSum - 1) / m -
            (double)(mDelta - subSum1) / (m * prjs[iZero - iSubSum]);
        }
      }
    }
    // The minimization step
    depth = min(depth, partDepth);
  }
  // Release memory structures
  delete[] prjs;
  delete[] curDir;
  delete[] tmpCurDir;
  return depth;
}
