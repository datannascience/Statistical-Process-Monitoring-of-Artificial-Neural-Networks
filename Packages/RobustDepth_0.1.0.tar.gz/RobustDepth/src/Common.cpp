#include "incRobustDepth.h"

// by rows
TDMatrix asMatrix(double* arr, int n, int d){
	TDMatrix mat = new double*[n];
	for (int i = 0; i < n; i++)
		mat[i] = arr + i*d;
	return mat;
}

double** newM(int n, int d){
	double* a = new double[n*d];
	return asMatrix(a, n, d);
}

void deleteM(TDMatrix X){
	delete[] X[0];
	delete[] X;
}

TDMatrix copyM(TDMatrix X, int n, int d){
	double* a = new double[n*d];
	memcpy(a, X[0], n*d*sizeof(double));
	return asMatrix(a, n, d);
}

void printMatrix(TDMatrix mat, int n, int d){
	for (int i = 0; i < n; i++){
		for (int j = 0; j < d; j++)
			Rcout << mat[i][j] << "\t";
		Rcout << endl;
	}
	Rcout << endl;
}

bool OUT_ALPHA = false;

void outString(char const * str){
#ifdef DEF_OUT_ALPHA
	if (!OUT_ALPHA) return;
	Rcout << str << endl;
#endif
}

int Compare(double &p1, double &p2){
  return p1 < p2;
}

void Swap(double *p1, double *p2){
  double pTmp = *p1;
  *p1 = *p2;
  *p2 = pTmp;
}
