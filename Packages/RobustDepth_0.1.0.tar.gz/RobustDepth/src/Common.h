#pragma once

//#define DEF_OUT_ALPHA
extern bool OUT_ALPHA;
#ifndef _MSC_VER
#define DEF_OUT_ALPHA
#endif
#ifdef DEF_OUT_ALPHA
using namespace Rcpp;
#endif

void outString(char const * str);

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

template<typename T>
int Compare(T &p1, T &p2) {
  return p1 < p2;
}
template<typename T>
void Swap(T *p1, T *p2) {
  T pTmp = *p1;
  *p1 = *p2;
  *p2 = pTmp;
};

/* -------------------------------------------------------------------------- */
/* quickSort from http://www.proggen.org/doku.php?id=algo:quicksort           */
/* (modified, templated)                                                      */
/* -------------------------------------------------------------------------- */
template<typename T> void quickSort(T *values, int left, int right, int(*cmp)
                                      (T& x, T& y), void(*swap)(T* x, T* y)){
  int i = left, j = right; // Z?hlindizes
  // Pivot-Element (Array-Mitte) bestimmen
  T pivot = values[(left + right) >> 1];
  // Solange Paare suchen und tauschen, bis sich die Z?hlindizes "getroffen"
  // haben
  do{
    // Paar finden, dass getauscht werden muss
    while (cmp(values[i], pivot)){++i;}
    while (cmp(pivot, values[j])){--j;}
    // Wenn sich die Z?hlindizes noch nicht "getroffen" haben, dann
    // tauschen und weiterz?hlen. Sollten die Z?hlindizes gleich sein, dann
    // z?hle einfach weiter und unterbrich die Schleife
    if (i < j){swap(&values[i], &values[j]);++i;--j;
    }else{if (i == j){++i;--j;break;}}
  }while (i <= j);
  // Wenn die Teillisten mehr als ein Element enthalten, dann wende quickSort
  // auf sie an
  if (left < j){quickSort(values, left, j, cmp, swap);}
  if (i < right){quickSort(values, i, right, cmp, swap);}
}

template<typename T> void quickSort(T *values, int left, int right){
  quickSort(values, left, right, Compare, Swap);
}
