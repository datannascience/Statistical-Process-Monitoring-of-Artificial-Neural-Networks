#include "incRobustDepth.h"

#define EOF (-1)

#ifdef __cplusplus
extern "C" {
#endif

  void dynRobustTukey(double* points, double* objects, int* numPoints,
                      int* numObjects, int* dimension, double* delta,
                      int* posExt, int* exact, int* nDir, int* genDirs,
                      double* sqrtCov, double* depths){
    RNGScope rngScope;
    TDMatrix X = asMatrix(objects, *numObjects, *dimension);
    TDMatrix sCov = asMatrix(sqrtCov, *dimension, *dimension);

    //GetRNGstate();
    if (!*exact){
      for (int i = 0; i < *numPoints; i++){
        depths[i] = RobustTukeyOneApx(points + i * *dimension, X, *numObjects,
                                      *dimension, *delta, (bool)(*posExt),
                                      *nDir, *genDirs, sCov);
      }
    }
    //PutRNGstate();

    delete[] X;
    delete[] sCov;
  }

#ifdef __cplusplus
}
#endif
