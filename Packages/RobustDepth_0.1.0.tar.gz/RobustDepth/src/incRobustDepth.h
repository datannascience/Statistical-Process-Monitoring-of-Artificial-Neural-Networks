#pragma once

#ifndef _MSC_VER
#include <Rcpp.h>
using namespace Rcpp;
#endif

#include <vector>
#include <math.h>
using namespace std;

#include "DataStructures.h"
#include "Common.h"
#include "RobustTukey.h"
