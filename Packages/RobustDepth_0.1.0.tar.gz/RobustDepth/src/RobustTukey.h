double RobustTukeyOneApx(double* point, TDMatrix objects, int m, int d,
                         double delta, bool posExt, int nDir, int genDirs,
                         TDMatrix sqrtCov);
