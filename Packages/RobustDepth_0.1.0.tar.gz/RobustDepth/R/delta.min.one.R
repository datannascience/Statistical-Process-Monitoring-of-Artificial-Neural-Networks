#a silly implementation; use determinats to compare two vectors?
#ignore 0 vector
sortPoints=function(v){
  #handle neg halfline
  vn=v[which(v[,2]<=0),]
  if(length(vn)>2){ #more than one element
    angle=vn[,1]/sqrt(vn[,1]^2+vn[,2]^2)
    ind=order(angle,decreasing=T)
    vn=vn[ind,]
  }
  vp=v[which(v[,2]>0),]
  if(length(vp)>2){
    angle=vp[,1]/sqrt(vp[,1]^2+vp[,2]^2)
    ind=order(angle)
    vp=vp[ind,]
  }
  rbind(vn,vp)
}

#not needed in the following
checkI=function(v,I){
  if (length(I)==1)
    vec=v[I,]
  else
    vec=colSums(v[I,])
  ind=which(v[,1]*vec[1]+v[,2]*vec[2]>0)
  (length(setdiff(ind,I))==0)
}

#assume that no 3 x-points are on the same line (not needed?)
minDeltaDepthOne=function(x,z=c(0,0)){
  maxNorm=0
  #numI=0
  n=length(x[,1])
  v=matrix(c(x[,1]-z[1],x[,2]-z[2]),ncol=2)
  v=sortPoints(v)
  for (i in 1:(2*n)){
    if (i==1){ #initialize
      I=which(v[,2]<=0)
      first=1
      if(length(I)>0)
         last=max(I)
      else{
        I=1
        last=1
      }
    }
    else{ #update
      a=v[first,]
      nxt=last+1
      if (nxt>n)
        nxt=1
      b=v[nxt,]
      det=a[1]*b[2]-a[2]*b[1]
      if (nxt==first) #I is full set
        det=1 #just exclude first
      if (det<=0){ #include next
        I=c(I,nxt)
        last=nxt
      }
      if (det>=0){ #exclude first
        I=I[-1]
        if(length(I)>0)
          first=I[1]
        else{
          I=nxt
          first=nxt
          last=nxt
        }
      }
    }
    #if (checkI(v,I))
     # numI=numI+1
    if (length(I)==1)
      vec=v[I,]
    else
      vec=colSums(v[I,]) #does not take a single row
    res=sqrt(vec[1]^2+vec[2]^2)/n
    if (res>maxNorm){
      maxNorm=res
      #maxLegal=checkI(v,I)
    }
  }
  #c(maxNorm,numI,maxLegal)
  maxNorm
}

delta.min.one <- function(x, data){
  if (!is.matrix(x)){
    return (minDeltaDepthOne(data, x))
  }else{
    deltas <- rep(-1, nrow(x))
    for (i in 1:nrow(x)){
      deltas[i] <- minDeltaDepthOne(data, x[i,])
    }
    return (deltas)
  }
}
