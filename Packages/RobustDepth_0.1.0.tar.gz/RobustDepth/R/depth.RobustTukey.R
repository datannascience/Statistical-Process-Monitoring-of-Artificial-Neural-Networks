depth.RobustTukey <- function(x, data, delta = 0.1, positive = TRUE,
                              exact = FALSE, method = "unifsp", num.dir = 1000,
                              sqrtCov = NULL){
  if (!is.matrix(x)){
    x <- matrix(as.vector(x), nrow = 1)
  }
  if (!is.matrix(data)){
    data <- matrix(as.vector(data), nrow = 1)
  }
  if (!exact){
    iGenAngles <- 0
    if (toupper(method) == "UNIFSP"){
      iGenAngles <- 1;
    }
    if (toupper(method) == "UNIFGR"){
      iGenAngles <- 2;
    }
    if (is.null(sqrtCov)){
      l1 <- diag(ncol(data))
    }else{
      if (toupper(sqrtCov) == "MOMENT"){
        s1 <- svd(cov(data))
        l1 <- s1$v %*% diag(sqrt(1/s1$d))
      }else{
        l1 <- sqrtCov
      }
    }
    tmpRes <- .C("dynRobustTukey", as.double(t(x)), as.double(t(data)),
                 as.integer(nrow(x)), as.integer(nrow(data)),
                 as.integer(ncol(data)), as.double(delta), as.integer(positive),
                 as.integer(exact), as.integer(num.dir), as.integer(iGenAngles),
                 as.double(t(l1)), depths = double(nrow(x)))
  }
  return (tmpRes$depths)
}
